/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 *
 * Examples:
 * One-shot model:
 *  User: "Alexa, tell Greeter to say hello"
 *  Alexa: "Hello World!"
 */

/**
 * App ID for the skill
 */
var APP_ID = "amzn1.echo-sdk-ams.app.b57218ae-d469-4687-83ec-df6fbaa430ea"; //replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";

/**
 * The AlexaSkill prototype and helper functions
 */

var http = require('http');
var https = require('https');

var AlexaSkill = require('./AlexaSkill');

/**
 * index.js is a child of AlexaSkill.
 */
var HelloWorld = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
HelloWorld.prototype = Object.create(AlexaSkill.prototype);
HelloWorld.prototype.constructor = HelloWorld;

HelloWorld.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("PNCAlexa Skill onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any initialization logic goes here


};

HelloWorld.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("PNCAlexa Skill onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    handleLaunch(session, response);
};

HelloWorld.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("HelloWorld onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any cleanup logic goes here
};

HelloWorld.prototype.intentHandlers = {


    "MyPinIs": function (intent, session, response) {

        var pincode = intent.slots.pincode;

        if(session.attributes.stage === 0) {

            if (pincode && pincode.value) {
                if (pincode.value === "1234") {
                    session.attributes.stage = 1;
                    response.tell("you now can access your account");
                }
                else {
                    session.attributes.stage = 0;
                    var speechOutput = "incorrect pin";
                    response.tell(speechOutput);
                }
            }
            else {
                session.attributes.stage = 0;
                var speechOutput = "You must say a pin";
                response.tell(speechOutput);
            }

        }
        else if(session.attributes.stage === 1) {
            response.tell("you are already logged in");
        }
        else{
            session.attributes.stage = 0;
            response.tell("problem getting your pin");
        }


    },
    "NearestAtmBranch": function (intent, session, response) {

        var zipcode = intent.slots.zipcode;
        var speechOutput = "";


            //if user entered a zipcode run bellow code..else run default zip of 15219
            if (zipcode && zipcode.value) {


                makeBranchLocatorRequest(zipcode.value, function tideResponseCallback(err, highTideResponse) {



                    if (err) {
                        speechOutput = "Sorry, we're having trouble accessing the data";
                    } else {

                        var atmCount = highTideResponse["atmCount"];
                        var branchCount = highTideResponse["branchCount"];

                        var zip1 = zipcode.value.substring(0, 1);
                        var zip2 = zipcode.value.substring(1, 2);
                        var zip3 = zipcode.value.substring(2, 3);
                        var zip4 = zipcode.value.substring(3, 4);
                        var zip5 = zipcode.value.substring(4, 5);


                        speechOutput = "There are currently " + atmCount + " ATMs and " + branchCount +
                            " branches within the zip code " + zip1 + " " + zip2 + " " + zip3 + " " + zip4 + " " + zip5;
                    }
                    response.tellWithCard(speechOutput, "Branch/ATM Information", speechOutput);

                });

            }
            else {

                makeBranchLocatorRequest(15219, function tideResponseCallback(err, highTideResponse) {
                    var speechOutput;

                    if (err) {
                        speechOutput = "Sorry, we're having trouble accessing the data";
                    } else {

                        var atmCount = highTideResponse["atmCount"];
                        var branchCount = highTideResponse["branchCount"];


                        speechOutput = "There are currently " + atmCount + " ATMs and " + branchCount +
                            " branches within the zipcode 1 5 2 1 9";
                    }
                    response.tellWithCard(speechOutput, "Branch/ATM Information", speechOutput);

                });

            }



    },
    "WhatsMyAccountBalance": function (intent, session, response) {


        //user must be logged in get account balance.
        if(session.attributes.stage === 1) {

            makeAccountBalanceRequest(function tideResponseCallback(err, highTideResponse) {


                if (err) {
                    speechOutput = "Sorry, we're having trouble accessing the data";
                } else {


                    //var responseString = JSON.stringify(highTideResponse);
                    var accountBalance1 = highTideResponse["accountBalanceData"][0]["accountBalance"];
                    var accountBalance2 = highTideResponse["accountBalanceData"][1]["accountBalance"];
                    var accountBalance3 = highTideResponse["accountBalanceData"][2]["accountBalance"];

                    var accountName1 = highTideResponse["accountBalanceData"][0]["accountDescription"];
                    var accountName2 = highTideResponse["accountBalanceData"][1]["accountDescription"];
                    var accountName3 = highTideResponse["accountBalanceData"][2]["accountDescription"];


                    speechOutput = "The balance for your " + accountName1 + " is " + accountBalance1 +
                    " dollars. The balance for your " + accountName2 + " is " + accountBalance2 +
                    " dollars. The balance for your " + accountName3 + " is " + accountBalance3 + " dollars.";
                }
                response.tellWithCard(speechOutput, "Account Information", speechOutput);

            });


        }
        //user is not logged in
        else{
            //user is not logged in, prompt
            response.tell("You must be logged in to get account balance, what's your pin?");

        }

    },

    "Transactions": function (intent, session, response) {

        var date = intent.slots.date;


        //user must be logged in get account balance.
        if(session.attributes.stage === 1) {

            makeTransactionsRequest(function tideResponseCallback(err, highTideResponse) {


                if (err) {
                    speechOutput = "Sorry, we're having trouble accessing the data";
                } else {

                    var responseString = JSON.stringify(highTideResponse);
                    //var accountBalance1 = highTideResponse["accountBalanceData"][0]["accountBalance"];

                    //var datastuff = highTideResponse;


                    speechOutput = "Response date is : " + date.value;
                }
                response.tellWithCard(speechOutput, "Account Information", speechOutput);

            });


        }
        //user is not logged in
        else{
            //user is not logged in, prompt
            response.tell("You must be logged in to get transactions information, what's your pin?");

        }

    },



    "StockInformation": function (intent, session, response) {
        var speechOutput = "";



            makeTideRequest(function tideResponseCallback(err, highTideResponse) {


                if (err) {
                    speechOutput = "Sorry, we're having trouble accessing the data";
                } else {

                    var priceRaw = highTideResponse["list"]["resources"][0]["resource"]["fields"]["price"];
                    var daylowRaw = highTideResponse["list"]["resources"][0]["resource"]["fields"]["day_low"];
                    var dayhighRaw = highTideResponse["list"]["resources"][0]["resource"]["fields"]["day_high"];

                    var priceDollar = priceRaw.substring(0, 2);
                    var priceCent = priceRaw.substring(3, 5);
                    var daylowDollar = daylowRaw.substring(0, 2);
                    var daylowCent = daylowRaw.substring(3, 5);
                    var dayhighDollar = dayhighRaw.substring(0, 2);
                    var dayHighCent = dayhighRaw.substring(3, 5);

                    speechOutput = "The current PNC stock price is " + priceDollar + " dollars and " + priceCent + " cents. With a day low at " + daylowDollar + " " +
                        "dollars and " + daylowCent + " cents. and a day high of " + +dayhighDollar + " dollars and " + dayHighCent + " cents.";
                }

                response.tellWithCard(speechOutput, "PNC Stocks", speechOutput)
            });





    },
    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("You can ask me things like, what's the nearest branch around me, or what's my account balance");
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        session.attributes.stage = 0;
        var speechOutput = "You don't have to yell";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        session.attributes.stage = 0;
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    }
};





function handleLaunch(session, response) {
    var speechText = "";

    //Reprompt speech will be triggered if the user doesn't respond.
    var repromptText = "You can ask me about your account balance";

    //Check if session variables are already initialized.
    if (session.attributes.stage) {

        //Ensure the dialogue is on the correct stage.
        if (session.attributes.stage === 0) {
            //User: Alexa open pnc
            speechText = "Welcome to PNC, how can I help you?";

        } else{
            //The user said open pnc while already logged in
            speechText = "You are logged in, how can I help you?";
        }

        //session doesn't exist for some reason, set it to 0 and prompt pi
    } else {
        session.attributes.stage = 0;
        speechText = "Welcome to PNC, how can I help you?";
    }

    var speechOutput = {
        speech: speechText,
        type: AlexaSkill.speechOutputType.PLAIN_TEXT
    };
    var repromptOutput = {
        speech: repromptText,
        type: AlexaSkill.speechOutputType.PLAIN_TEXT
    };
    response.askWithCard(speechOutput, repromptOutput, "Welcome to PNC", speechText);
}



function makeAccountBalanceRequest(tideResponseCallback) {

   // var endpoint = 'https://apilink-qa.pnc.com/hackathon/qa/retail/accountBalances/v1/getAccountBalances?customerKey=709572';



    var options = {
        "method": "GET",
        "hostname": "apilink-qa.pnc.com",
        "port": null,
        "path": "https://apilink-qa.pnc.com/hackathon/qa/retail/accountBalances/v1/getAccountBalances?customerKey=709572 ",
        "headers": {
            "accept": "application/json",
            "x-ibm-client-id": "20c0a016-b720-4b6a-92b5-f587e5552a2b"
        }
    };

    var req = https.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            var body = Buffer.concat(chunks);
            console.log(body.toString());

            if (body.error) {
                console.log("NOAA error: " +"some error");
                tideResponseCallback(new Error("some error"));
            } else {
                var jsonResponse = JSON.parse(body);
                tideResponseCallback(null, jsonResponse);
            }


        });
    });

    req.end();


}


function makeTideRequest(tideResponseCallback) {

    var endpoint = 'http://finance.yahoo.com/webservice/v1/symbols/pnc/quote?format=json&view=detail';


    http.get(endpoint, function (res) {
        var noaaResponseString = '';
        console.log('Status Code: ' + res.statusCode);

        if (res.statusCode != 200) {
            tideResponseCallback(new Error("Non 200 Response"));
        }

        res.on('data', function (data) {
            noaaResponseString += data;
        });

        res.on('end', function () {
            var noaaResponseObject = JSON.parse(noaaResponseString);

            if (noaaResponseObject.error) {
                console.log("NOAA error: " +"some error");
                tideResponseCallback(new Error("some error"));
            } else {
                var highTide = noaaResponseObject;
                tideResponseCallback(null, highTide);
            }
        });
    }).on('error', function (e) {
        console.log("Communications error: " + e.message);
        tideResponseCallback(new Error(e.message));
    });
    }

function makeBranchLocatorRequest(zipValue,tideResponseCallback) {

    var endpoint;

    //if user provided zip code with intent look up, if not default to 15219
    if(zipValue){
        endpoint = 'https://apilink-qa.pnc.com/hackathon/qa/locator/api/v1/location?radiusUnits=mi&limit=0&zip='+ zipValue + '&radius=10&offset=0';
    }else{
        endpoint = 'https://apilink-qa.pnc.com/hackathon/qa/locator/api/v1/location?radiusUnits=mi&limit=0&zip=15219&radius=10&offset=0';
    }


    https.get(endpoint, function (res) {
        var noaaResponseString = '';
        console.log('Status Code: ' + res.statusCode);

        if (res.statusCode != 200) {
            tideResponseCallback(new Error("Non 200 Response"));
        }

        res.on('data', function (data) {
            noaaResponseString += data;
        });

        res.on('end', function () {
            var noaaResponseObject = JSON.parse(noaaResponseString);

            if (noaaResponseObject.error) {
                console.log("NOAA error: " +"some error");
                tideResponseCallback(new Error("some error"));
            } else {
                var highTide = noaaResponseObject;
                tideResponseCallback(null, highTide);
            }
        });
    }).on('error', function (e) {
        console.log("Communications error: " + e.message);
        tideResponseCallback(new Error(e.message));
    });



}


function makeTransactionsRequest(tideResponseCallback) {

    // var endpoint = 'https://apilink-qa.pnc.com/hackathon/qa/retail/accountBalances/v1/getAccountBalances?customerKey=709572';

    var options = {
        "method": "GET",
        "hostname": "apilink-qa.pnc.com",
        "port": null,
        "path": "https://apilink-qa.pnc.com/hackathon/qa/retail/spendBudget/v1/CashflowTransactions?startDate=2015-01-27&customerKey=709572&endDate=2015-01-27",
        "headers": {
            "accept": "application/json",
            "x-ibm-client-id": "20c0a016-b720-4b6a-92b5-f587e5552a2b"
        }
    };

    var req = https.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            var body = Buffer.concat(chunks);
            console.log(body.toString());

            if (body.error) {
                console.log("NOAA error: " +"some error");
                tideResponseCallback(new Error("some error"));
            } else {
                var jsonResponse = JSON.parse(body);
                tideResponseCallback(null, jsonResponse);
            }


        });
    });

    req.end();


}





// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    // Create an instance of the HelloWorld skill.
    var helloWorld = new HelloWorld();
    helloWorld.execute(event, context);
};

